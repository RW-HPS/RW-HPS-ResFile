<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Dirt" tilewidth="20" tileheight="20">
 <image source="bitmaps/dirt.png" trans="008a76"/>
</tileset>
