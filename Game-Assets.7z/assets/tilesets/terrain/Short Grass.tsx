<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Short Grass" tilewidth="20" tileheight="20">
 <image source="bitmaps/shortgrass.png" trans="008a76"/>
</tileset>
