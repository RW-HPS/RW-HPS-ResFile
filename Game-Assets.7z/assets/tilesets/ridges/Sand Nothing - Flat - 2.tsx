<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Sand Nothing - Flat - 2" tilewidth="20" tileheight="20" tilecount="21" columns="3">
 <image source="bitmaps/sand2nothing_flat.png" trans="008a76" width="60" height="140"/>
</tileset>
